# Refactoring

You've been asked to refactor the function `deterministicPartitionKey` in [`dpk.js`](dpk.js) to make it easier to read and understand without changing its functionality. For this task, you should:

1. Write unit tests to cover the existing functionality and ensure that your refactor doesn't break it. We typically use `jest`, but if you have another library you prefer, feel free to use it.
2. Refactor the function to be as "clean" and "readable" as possible. There are many valid ways to define those words - use your own personal definitions, but be prepared to defend them. Note that we do like to use the latest JS language features when applicable.

3. Write up a brief (~1 paragraph) explanation of why you made the choices you did and why specifically your version is more "readable" than the original.

You will be graded on the exhaustiveness and quality of your unit tests, the depth of your refactor, and the level of insight into your thought process provided by the written explanation.

## Your Explanation Here
1. 
describe("deterministicPartitionKey tests", () => {
 test('when partition key exists', () => {
   expect(deterministicPartitionKey({partitionKey:"partitionKeysample"})).toBe("the value got from sha3- 512");
 });
  test('when event exists but paritionKey does not exist', () => {
   expect(deterministicPartitionKey({})).toBe("0");
 });
   test('when event does exist', () => {
   expect(deterministicPartitionKey()).toBe("0");
 });
})


2.  
const crypto = require("crypto");

exports.deterministicPartitionKey = (event) => {
  const TRIVIAL_PARTITION_KEY = "0";
  const MAX_PARTITION_KEY_LENGTH = 256;
  let candidate;
  # !! used to check correctly event is empty or not as well as null or undefined
  if (!!event) {
    if (!!event.partitionKey) {
      candidate = event.partitionKey;
      // we don't need to separate these conditions.
      candidate = JSON.stringify(candidate);
      if (candidate.length > MAX_PARTITION_KEY_LENGTH) {
        # make the hash value of candidate
        candidate = crypto.createHash("sha3-512").update(candidate).digest("hex");
      }  
    } else {
      # if event has not partitionKey, it is converted as Json and then make the hash value of that.
      const data = JSON.stringify(event);
      candidate = crypto.createHash("sha3-512").update(data).digest("hex");
    }
  }
  else{
    # if event is null, candidate set the init value("0")
    candidate = TRIVIAL_PARTITION_KEY;
  }
  return candidate;
};

